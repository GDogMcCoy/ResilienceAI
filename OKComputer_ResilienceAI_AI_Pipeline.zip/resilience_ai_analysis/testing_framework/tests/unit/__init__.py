"""
Unit tests for ResilienceAI
"""
